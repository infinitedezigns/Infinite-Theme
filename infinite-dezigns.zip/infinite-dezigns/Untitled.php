/**
 * Enqueue scripts and styles.
 */
function wordpress_dealership_scripts() {
  wp_enqueue_style( 'wordpress-dealership-style', get_stylesheet_uri() );
  
  /* Add Foundation CSS */
  wp_enqueue_style( 'foundation-normalize', get_stylesheet_directory_uri() . '/foundation/css/normalize.css' );
  wp_enqueue_style( 'foundation', get_stylesheet_directory_uri() . '/foundation/css/foundation.css' );
  
  /* Add Custom CSS */
  wp_enqueue_style( 'foundation-icons', get_stylesheet_directory_uri() . '/foundation-icons/foundation-icons.css', array(), '1' );
  
  /* Add Custom CSS */
  wp_enqueue_style( 'wordpress-dealership-custom-style', get_stylesheet_directory_uri() . '/custom.css', array(), '1' );
  
  /* Add Foundation JS */
  wp_enqueue_script( 'foundation-js', get_template_directory_uri() . '/foundation-5.5.0/js/foundation.min.js', array( 'jquery' ), '1', true );
  wp_enqueue_script( 'foundation-modernizr-js', get_template_directory_uri() . '/foundation-5.5.0/js/vendor/modernizr.js', array( 'jquery' ), '1', false );
  wp_enqueue_script( 'foundation-fastclick-js', get_template_directory_uri() . '/foundation-5.5.0/js/vendor/fastclick.js', false, '1', true );
  
  /* Foundation Init JS */
  wp_enqueue_script( 'foundation-init-js', get_template_directory_uri() . '/foundation.js', array( 'jquery' ), '1', true );

  wp_enqueue_script( 'wordpress-dealership-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20120206', true );

  wp_enqueue_script( 'wordpress-dealership-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

  if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
    wp_enqueue_script( 'comment-reply' );
  }
}
add_action( 'wp_enqueue_scripts', 'wordpress_dealership_scripts' );